package com.example.mobexam;

public interface Delete {
    public void deleted();
}
